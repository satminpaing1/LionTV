package com.satminpaing.mytvapp

import android.annotation.SuppressLint
import android.app.UiModeManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var originalSystemUiVisibility: Int = 0
    private var originalOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED // Store original orientation

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure the window to be fullscreen and hide system bars
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        // Create a root FrameLayout programmatically to hold the WebView
        // This avoids needing an XML layout file (e.g., activity_main.xml)
        val rootLayout = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        setContentView(rootLayout)

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        rootLayout.addView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            // Append a custom string to the default User-Agent
            userAgentString = userAgentString + " Mobile TV_App"
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                view?.loadUrl(request?.url.toString())
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                // Optional: Show a loading indicator here
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Optional: Hide loading indicator here
            }
        }

        // [NEW FEATURE] Auto-Landscape Video Logic
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                // If a custom view is already showing, hide it first
                if (customView != null) {
                    onHideCustomView()
                    return
                }

                customView = view
                customViewCallback = callback
                originalSystemUiVisibility = window.decorView.systemUiVisibility // Store original UI visibility
                originalOrientation = requestedOrientation // Store original orientation

                // Set fullscreen flags to hide status and navigation bars
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

                // Add the custom view (e.g., video player) to the activity's decor view
                val decorView = window.decorView as FrameLayout
                decorView.addView(
                    customView,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                webView.visibility = View.GONE // Hide the WebView behind the custom view

                // If the device is a phone (not TV), force landscape orientation for full-screen video
                if (!isTvDevice(this@MainActivity)) {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                }
            }

            override fun onHideCustomView() {
                if (customView == null) {
                    return
                }

                // Restore original system UI visibility
                window.decorView.systemUiVisibility = originalSystemUiVisibility

                // Remove the custom view from the decor view
                val decorView = window.decorView as FrameLayout
                decorView.removeView(customView)

                customView = null
                customViewCallback?.onCustomViewHidden()
                webView.visibility = View.VISIBLE // Show the WebView again

                // If the device is a phone, restore original orientation
                if (!isTvDevice(this@MainActivity)) {
                    requestedOrientation = originalOrientation
                }
            }
        }

        webView.loadUrl("https://blue-lion-tv.netlify.app/")
    }

    override fun onBackPressed() {
        if (customView != null) {
            // If a custom view (e.g., fullscreen video) is showing, hide it first
            webView.webChromeClient.onHideCustomView()
        } else if (webView.canGoBack()) {
            // If WebView can go back, navigate to the previous page
            webView.goBack()
        } else {
            // Otherwise, perform the default back action (exit app)
            super.onBackPressed()
        }
    }

    // Helper function to detect if the device is an Android TV
    private fun isTvDevice(context: Context): Boolean {
        val uiModeManager = context.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        return uiModeManager.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
    }

    // Handle D-Pad key events for Android TV
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (isTvDevice(this)) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    // WebView typically handles these by simulating a click on the focused element.
                    // No explicit action needed here unless custom behavior is desired.
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (webView.canGoBack()) {
                        webView.goBack()
                        return true
                    }
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (webView.canGoForward()) {
                        webView.goForward()
                        return true
                    }
                }
                // D-Pad UP/DOWN usually scrolls, which WebView handles by default.
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // Lifecycle methods for WebView to manage resources properly
    override fun onPause() {
        super.onPause()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        super.onDestroy()
        webView.destroy() // Destroy the WebView to prevent memory leaks
    }
}

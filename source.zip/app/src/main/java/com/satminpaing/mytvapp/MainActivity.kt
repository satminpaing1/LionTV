package com.satminpaing.mytvapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val pwaUrl = "https://blue-lion-tv.netlify.app"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        // WebView settings
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false

            // Enable mixed content mode for HTTPS sites loading HTTP resources
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

            // Append " Mobile TV" to the default User-Agent
            val defaultUserAgent = userAgentString
            userAgentString = "$defaultUserAgent Mobile TV"

            // Configure for better TV experience (optional, but good for D-Pad)
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false // Hide zoom controls, TV usually doesn't need them
            displayZoomControls = false
        }

        // CRITICAL: Handle D-Pad Navigation for TV & WebView focus
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        webView.requestFocus(View.FOCUS_DOWN) // Request initial focus

        // CRITICAL: WebViewClient to keep links inside the app
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                // Returning false means the current WebView should handle the URL,
                // effectively keeping all navigation within the app's WebView.
                return false
            }
        }

        // Load the PWA URL
        webView.loadUrl(pwaUrl)
    }

    // Handle 'onBackPressed' to go back in WebView history before closing the app
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
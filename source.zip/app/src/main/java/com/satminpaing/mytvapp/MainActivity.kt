package com.satminpaing.mytvapp

import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val PWA_URL = "https://blue-lion-tv.netlify.app/"
    private val TV_USER_AGENT = "Mozilla/5.0 (Linux; Android 9; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.0.0 TV Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        webView = WebView(this).apply {
            // Set layout parameters for the WebView to fill the parent
            layoutParams = android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        setContentView(webView)

        setupWebView()
        webView.loadUrl(PWA_URL)

        // Ensure WebView is focusable for D-Pad navigation
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        webView.requestFocus()
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            // Enable hardware acceleration for better performance
            setLayerType(View.LAYER_TYPE_HARDWARE, null)

            // Set TV-specific User-Agent
            userAgentString = TV_USER_AGENT

            // Improve performance for modern web views
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false // No zoom for TV
            displayZoomControls = false // No zoom for TV
            cacheMode = WebSettings.LOAD_DEFAULT // Use default caching strategy
            
            // Potentially enable remote debugging for WebView (for development)
            // if (BuildConfig.DEBUG) {
            //    WebView.setWebContentsDebuggingEnabled(true)
            // }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString()
                if (url != null && view != null) {
                    // Load all links within the same WebView to keep navigation inside the app
                    view.loadUrl(url)
                    return true // Indicate that the app has handled the URL loading.
                }
                return false // Let the WebView handle other cases or null URLs.
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
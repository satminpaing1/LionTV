package com.satminpaing.mytvapp

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity

// [UPDATED] Live Soccer TV Mode: Auto-Landscape & Fullscreen Enabled
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var originalOrientation: Int = 0
    private var originalSystemUiVisibility: Int = 0
    private var fullscreenContainer: FrameLayout? = null

    private val WEBSITE_URL = "https://blue-lion-tv.netlify.app/"
    private val USER_AGENT_SUFFIX = " Mobile TV_App"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Ensure you have an activity_main.xml with a WebView element like: <WebView android:id="@+id/webView" .../>

        webView = findViewById(R.id.webView)

        webView.apply {
            webChromeClient = MyWebChromeClient()
            webViewClient = MyWebViewClient()

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                // Append custom string to default User-Agent
                userAgentString = settings.userAgentString + USER_AGENT_SUFFIX
            }
            // Set background to black to prevent white flashes during video loading or fullscreen transitions
            setBackgroundColor(Color.BLACK)
            loadUrl(WEBSITE_URL)
        }
    }

    private fun isTvDevice(): Boolean {
        val uiModeManager = getSystemService(UI_MODE_SERVICE) as? android.app.UiModeManager
        return uiModeManager?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
    }

    inner class MyWebChromeClient : WebChromeClient() {
        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
            // If already showing a custom view, hide it first
            if (this.customView != null) {
                onHideCustomView()
                return
            }

            customView = view
            customViewCallback = callback
            originalOrientation = requestedOrientation
            originalSystemUiVisibility = window.decorView.systemUiVisibility

            // Hide status bar and navigation bar for fullscreen experience
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)

            // Force landscape orientation if it's a mobile device (not TV)
            if (!isTvDevice()) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }

            val decorView = window.decorView as FrameLayout
            fullscreenContainer = FrameLayout(this@MainActivity).apply {
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(Color.BLACK)
                addView(customView)
            }
            decorView.addView(fullscreenContainer, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }

        override fun onHideCustomView() {
            if (customView == null) {
                return
            }

            val decorView = window.decorView as FrameLayout
            decorView.removeView(fullscreenContainer)
            fullscreenContainer = null

            // Restore original system UI visibility and orientation
            window.decorView.systemUiVisibility = originalSystemUiVisibility
            requestedOrientation = originalOrientation

            customView = null
            customViewCallback?.onCustomViewHidden()
            customViewCallback = null
        }
    }

    inner class MyWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            view?.loadUrl(request?.url.toString())
            return true
        }
    }

    override fun onBackPressed() {
        if (customView != null) {
            // If a custom view (e.g., fullscreen video) is active, hide it first
            (webView.webChromeClient as? MyWebChromeClient)?.onHideCustomView()
        } else if (webView.canGoBack()) {
            // Navigate back in WebView history
            webView.goBack()
        } else {
            // If no more history, exit the app
            super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        webView.destroy()
    }
}
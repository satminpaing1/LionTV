package com.satminpaing.mytvapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val pwaUrl = "https://blue-lion-tv.netlify.app/"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // NOTE: This assumes you have an activity_main.xml layout file
        // with a WebView component defined and its ID set to 'webview'.
        // Example activity_main.xml:
        // <WebView android:id="@+id/webview" android:layout_width="match_parent" android:layout_height="match_parent" />
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)

        // WebSettings configuration
        val webSettings: WebSettings = webView.settings
        webSettings.javaScriptEnabled = true // Enable JavaScript
        webSettings.domStorageEnabled = true // Enable DOM Storage
        webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW // Enable Mixed Content Mode
        
        // Set User-Agent: Use a generic Android string that works on both TV and Mobile
        webSettings.userAgentString = webSettings.userAgentString + " Mobile TV" 
        
        webSettings.allowFileAccess = true // Allow WebView to access local files, if needed by PWA

        // Enable hardware acceleration for the WebView (also controlled by manifest for the Activity)
        webView.setLayerType(WebView.LAYER_TYPE_HARDWARE, null)

        // Set WebViewClient to keep links inside the app
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url != null) {
                    view?.loadUrl(url)
                }
                return true // Return true to indicate the app handles the URL internally
            }
        }

        // Handle D-Pad Navigation for TV: Ensure the WebView is focusable.
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        webView.requestFocus() // Request focus initially for the WebView to handle D-Pad input

        // Load the PWA URL
        webView.loadUrl(pwaUrl)
    }

    // Handle 'onBackPressed' to go back in WebView history before closing the app
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack() // Go back in WebView history
        } else {
            super.onBackPressed() // Exit the app if no history in WebView
        }
    }

    // Handle D-Pad key events, specifically for back button on TV remote.
    // Other D-Pad navigation (left, right, up, down, center) will typically be handled 
    // by the WebView itself if the web content has focusable elements.
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
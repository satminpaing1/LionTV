package com.satminpaing.mytvapp

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var originalOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private var isFullscreenMode: Boolean = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Assuming activity_main.xml contains a WebView with ID 'webView'

        // Initialize WebView
        webView = findViewById(R.id.webView)

        // Configure WebView settings
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false // Allow autoplay
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            }
        }

        // Set custom User-Agent
        val originalUserAgent = webView.settings.userAgentString
        webView.settings.userAgentString = originalUserAgent + " Mobile TV_App"

        // Set WebViewClient to handle page navigation within the WebView
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url != null) {
                    view?.loadUrl(url)
                }
                return true
            }
        }

        // [NEW FEATURE] Auto-Landscape Video Logic
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    onHideCustomView()
                    return
                }

                customView = view
                customViewCallback = callback
                originalOrientation = requestedOrientation

                // Hide status bar and navigation bar for fullscreen
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)

                // Add the custom view
                (window.decorView as android.view.ViewGroup).addView(
                    customView,
                    android.view.ViewGroup.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )

                webView.visibility = View.GONE
                isFullscreenMode = true

                // Check device type: If it is a phone (not TV), force orientation to LANDSCAPE.
                val isTv = (applicationContext.resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION
                if (!isTv) { // Assuming it's a phone/tablet
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                }
            }

            override fun onHideCustomView() {
                if (customView == null) {
                    return
                }

                // Restore original UI visibility
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE

                // Remove the custom view
                (window.decorView as android.view.ViewGroup).removeView(customView)
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null

                webView.visibility = View.VISIBLE
                isFullscreenMode = false

                // Restore original orientation
                requestedOrientation = originalOrientation
            }
        }

        // Load the URL
        webView.loadUrl("https://blue-lion-tv.netlify.app/")
    }

    override fun onBackPressed() {
        if (isFullscreenMode) {
            webView.webChromeClient.onHideCustomView()
        } else if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Handle D-Pad navigation for Android TV
        // This provides basic scrolling for D-Pad UP/DOWN/LEFT/RIGHT.
        // WebView typically handles KEYCODE_DPAD_CENTER/ENTER on its own for focused elements.
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> webView.evaluateJavascript("window.scrollBy(0, -100);", null)
            KeyEvent.KEYCODE_DPAD_DOWN -> webView.evaluateJavascript("window.scrollBy(0, 100);", null)
            KeyEvent.KEYCODE_DPAD_LEFT -> webView.evaluateJavascript("window.scrollBy(-100, 0);", null)
            KeyEvent.KEYCODE_DPAD_RIGHT -> webView.evaluateJavascript("window.scrollBy(100, 0);", null)
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                // Let WebView handle click/focus for these keys
                return super.onKeyDown(keyCode, event)
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}

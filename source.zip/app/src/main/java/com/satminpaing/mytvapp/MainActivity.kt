package com.satminpaing.mytvapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {

    private lateinit var webView: WebView
    private val PWA_URL = "https://blue-lion-tv.netlify.app/"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                // CRITICAL: Set User-Agent to a TV string
                userAgentString = "Mozilla/5.0 (Linux; Android 9; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.0.0 TV Safari/537.36"
                // Other settings for better web experience on TV
                loadWithOverviewMode = true
                useWideViewPort = true
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                // Enable mixed content to allow HTTPS page load HTTP resources if any
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            }

            // CRITICAL: Add a 'WebViewClient' to keep links inside the app.
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    if (url != null) {
                        // Always load the URL within the WebView to keep navigation inside the app
                        view?.loadUrl(url)
                        return true
                    }
                    return false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    // Request focus once page is loaded
                    view?.requestFocus()
                }
            }

            // CRITICAL: Handle D-Pad Navigation. Ensure the WebView is focusable and requests focus.
            isFocusable = true
            isFocusableInTouchMode = true
            requestFocus() // Request initial focus

            // Load the PWA URL
            loadUrl(PWA_URL)
        }
        setContentView(webView)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        webView.destroy()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    // Override onKeyDown to ensure D-Pad events are correctly dispatched to the WebView.
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (event != null) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN,
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> {
                    // Let WebView handle D-Pad keys and Enter to allow web content interaction
                    webView.dispatchKeyEvent(event)
                    return true // Consume the event so the Activity doesn't handle it
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}
package com.satminpaing.mytvapp

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity

// [VERIFIED CODE] Supports Auto-Landscape on Video & D-Pad Navigation
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var originalOrientation: Int = 0
    private var originalSystemUiVisibility: Int = 0
    private lateinit var fullscreenContainer: FrameLayout

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Hide ActionBar completely
        supportActionBar?.hide()

        // Create main layout programmatically to avoid R.layout issues
        val rootLayout = FrameLayout(this)
        rootLayout.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )

        // Setup WebView
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        rootLayout.addView(webView)

        // Setup Fullscreen Container (Hidden by default)
        fullscreenContainer = FrameLayout(this)
        fullscreenContainer.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        fullscreenContainer.visibility = View.GONE
        fullscreenContainer.setBackgroundColor(-16777216) // Black color
        rootLayout.addView(fullscreenContainer)

        setContentView(rootLayout)

        // Configure WebView Settings
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        
        // Custom User Agent for compatibility
        settings.userAgentString = settings.userAgentString + " Mobile TV_App"

        // Handle Web Events
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return false // Keep everything inside the WebView
            }
        }

        // Handle Fullscreen Video Events
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }

                customView = view
                customViewCallback = callback
                
                // Save original state
                originalOrientation = requestedOrientation
                originalSystemUiVisibility = window.decorView.systemUiVisibility

                // Switch to Fullscreen Mode
                webView.visibility = View.GONE
                fullscreenContainer.addView(customView)
                fullscreenContainer.visibility = View.VISIBLE
                
                // Hide System Bars (Immersive Mode)
                window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

                // Force Landscape on Phones (Check if NOT TV)
                if (!isTvDevice()) {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                }
            }

            override fun onHideCustomView() {
                if (customView == null) return

                // Restore original state
                fullscreenContainer.removeView(customView)
                fullscreenContainer.visibility = View.GONE
                webView.visibility = View.VISIBLE
                
                window.decorView.systemUiVisibility = originalSystemUiVisibility
                requestedOrientation = originalOrientation

                customViewCallback?.onCustomViewHidden()
                customView = null
                customViewCallback = null
            }
            
            override fun getDefaultVideoPoster(): Bitmap? {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            }
        }

        // Load the User URL
        webView.loadUrl("https://blue-lion-tv.netlify.app/")
    }
    
    // Helper to detect if running on TV
    private fun isTvDevice(): Boolean {
        val uiMode = resources.configuration.uiMode
        return (uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK) == 
                android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
    }

    // Handle Back Button
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // Check if in fullscreen video mode
            if (customView != null) {
                webView.webChromeClient?.onHideCustomView()
                return true
            }
            // Check if WebView can go back
            if (webView.canGoBack()) {
                webView.goBack()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}
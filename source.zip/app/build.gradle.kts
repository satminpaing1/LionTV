
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.satminpaing.mytvapp" // Will be replaced in ZIP
    compileSdk = 33

    defaultConfig {
        applicationId = "com.satminpaing.mytvapp"
        minSdk = 24
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.9.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    // Added for better WebView performance
    implementation("androidx.webkit:webkit:1.8.0") 
    // Added to prevent 'Theme.Leanback' resource errors
    implementation("androidx.leanback:leanback:1.0.0") 
}
